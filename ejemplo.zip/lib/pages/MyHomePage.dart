import 'package:ejemplo/widgets/ListSalons.dart';
import 'package:flutter/material.dart';
import 'package:ejemplo/models/ModelBarbers.dart';
import 'package:ejemplo/providers/ProviderBarbers.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // declaración de la lista de los salones
  Future<List<ModelBarbers>>? _futureModelBarbers;

  @override
  void initState() {
    super.initState();
    // declaracion del modelo con el provider
    _futureModelBarbers = fetchModelBarbers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        // futurebuilder para poder mostrar los datos de la api
        child: FutureBuilder<List<ModelBarbers>>(
          future: _futureModelBarbers,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final modelBarbersList = snapshot.data!;
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    SizedBox(height: 20),
                    Container(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Beauty salons',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(0, 0, 0, 1),
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Your info',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(139, 140, 137, 1),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Expanded(
                      child: buildListSalon(modelBarbersList),
                    ),
                  ],
                ),
              );
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return CircularProgressIndicator();
            }
          },
        ),
      ),
    );
  }
}
