import 'package:flutter/material.dart';
import 'package:ejemplo/pages/MyHomePage.dart';

class WelcomePage extends StatelessWidget {
  static const String routeName = 'Welcome';
  const WelcomePage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 255, 255, 1),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              SizedBox(height: 80),
              Icon(
                Icons.cut,
                size: 150,
                color: Color.fromRGBO(20, 33, 61, 1),
              ),
              SizedBox(height: 50),
              Container(
                alignment: Alignment.bottomLeft,
                child: Text(
                  'Let’s Get Started',
                  style: TextStyle(
                    fontSize: 60,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(20, 33, 61, 1),
                  ),
                ),
              ),
              Container(
                alignment: Alignment.topLeft,
                child: Text(
                  'SalonSearch',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(139, 140, 137, 1),
                  ),
                ),
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MyHomePage(),
                    ),
                  );
                },
                child: Text('Search now'),
                style: ElevatedButton.styleFrom(
                    primary: Color.fromRGBO(252, 163, 17,
                        0.8), // Cambia el color de fondo del botón
                    onPrimary: Color.fromRGBO(229, 232, 225,
                        1), // Cambia el color del texto del botón
                    elevation: 10, // Cambia la elevación del botón
                    padding: EdgeInsets.symmetric(
                        vertical: 15,
                        horizontal: 30), // Cambia el padding del botón
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                          10), // Cambia la forma del botón
                    ),
                    minimumSize: Size(340, 60)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
