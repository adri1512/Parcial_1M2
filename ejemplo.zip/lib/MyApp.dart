import 'package:flutter/material.dart';
import 'package:ejemplo/pages/MyHomePage.dart';
import 'package:ejemplo/pages/WelcomePage.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'API Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),

        // Declaración de las rutas del sistemas
        initialRoute: '1',
        routes: {
          '1': (BuildContext context) => WelcomePage(),
          '2': (BuildContext context) => MyHomePage(),
        });
  }
}
