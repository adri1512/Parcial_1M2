import 'dart:convert';
import 'package:ejemplo/models/ModelBarbers.dart';
import 'package:http/http.dart' as http;

//provider donde consumo los datos de la api traidos del internet
Future<List<ModelBarbers>> fetchModelBarbers() async {
  final response = await http
      .get(Uri.parse('https://www.datos.gov.co/resource/e27n-di57.json'));
  if (response.statusCode == 200) {
    final List<dynamic> jsonList = json.decode(response.body);
    return jsonList.map((json) => ModelBarbers.fromJson(json)).toList();
  } else {
    throw Exception('Failed to fetch data');
  }
}
