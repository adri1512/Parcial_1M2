import 'package:flutter/material.dart';
import 'package:ejemplo/MyApp.dart';

void main() {
  runApp(MyApp());
}
