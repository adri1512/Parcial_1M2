import 'package:ejemplo/models/ModelBarbers.dart';
import 'package:flutter/material.dart';

// Widget para crear la lista de cartas donde se muestra la
// información de cada salon de belleza
ListView buildListSalon(List<ModelBarbers> modelBarbersList) {
  return ListView.builder(
    itemCount: modelBarbersList.length,
    itemBuilder: (context, index) {
      final modelBarbers = modelBarbersList[index];
      return InkWell(
        onTap: () {
          // Acción a realizar al hacer clic en el card
          // trate de hacer una pantalla donde solo mostrara la información
          // del salon a que le doy clic pero no pude  
          print('Card Button $index Tapped');
        },
        child: Column(
          children: [
            Card(
              elevation: 6,
              child: Column(
                children: [
                  ListTile(
                    title: Text(modelBarbers.razonSocial),
                    subtitle: Text(modelBarbers.organizacion),
                  ),
                  SizedBox(height: 10),
                  Container(
                    width: 362,
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(252, 163, 17, 1),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(6),
                        bottomRight: Radius.circular(6),
                      ), 
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: 20),
                        Row(
                          children: [
                            Icon(
                              Icons.place,
                              color: Color.fromRGBO(255, 255, 255, 1),
                            ),
                            SizedBox(width: 5),
                            Text(
                              modelBarbers.municipioComercial,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: Color.fromRGBO(255, 255, 255, 1),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.email,
                              color: Color.fromRGBO(255, 255, 255, 1),
                            ),
                            SizedBox(width: 5),
                            Text(
                              modelBarbers.emailComercial,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: Color.fromRGBO(255, 255, 255, 1),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
          ],
        ),
      );
    },
  );
}
