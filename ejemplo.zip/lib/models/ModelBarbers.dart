// Modelo de la información contenida en la api
// sacado desde la pagina de quicktype
class ModelBarbers {
  String matricula;
  String proponente;
  String organizacion;
  String estadoDeLaMatricula;
  String razonSocial;
  String nit;
  String fechaRenovacion;
  String ultimoAORenovado;
  String fechaConstitucion;
  String direccionComercial;
  String barrioComercial;
  String municipioComercial;
  String emailComercial;
  String ciiu1;
  String ciiu2;
  String ciiu3;
  String ciiu4;
  String actividad;
  String tamaOEmpresa;
  String matriculaPropietario;
  String nitPropietario;
  String camaraDePropietario;
  String nombreDePropietario;
  String direccionPropietario;
  String municipioPropietario;
  String emailPropietario;
  String representanteLegalSuplente;

  ModelBarbers({
    required this.matricula,
    required this.proponente,
    required this.organizacion,
    required this.estadoDeLaMatricula,
    required this.razonSocial,
    required this.nit,
    required this.fechaRenovacion,
    required this.ultimoAORenovado,
    required this.fechaConstitucion,
    required this.direccionComercial,
    required this.barrioComercial,
    required this.municipioComercial,
    required this.emailComercial,
    required this.ciiu1,
    required this.ciiu2,
    required this.ciiu3,
    required this.ciiu4,
    required this.actividad,
    required this.tamaOEmpresa,
    required this.matriculaPropietario,
    required this.nitPropietario,
    required this.camaraDePropietario,
    required this.nombreDePropietario,
    required this.direccionPropietario,
    required this.municipioPropietario,
    required this.emailPropietario,
    required this.representanteLegalSuplente,
  });

  factory ModelBarbers.fromJson(Map<String, dynamic> json) {
    return ModelBarbers(
      matricula: json["matricula"] ?? '',
      proponente: json["proponente"] ?? '',
      organizacion: json["organizacion"] ?? '',
      estadoDeLaMatricula: json["estado_de_la_matricula"] ?? '',
      razonSocial: json["razon_social"] ?? '',
      nit: json["nit"] ?? '',
      fechaRenovacion: json["fecha_renovacion"] ?? '',
      ultimoAORenovado: json["ultimo_a_o_renovado"] ?? '',
      fechaConstitucion: json["fecha_constitucion"] ?? '',
      direccionComercial: json["direccion_comercial"] ?? '',
      barrioComercial: json["barrio_comercial"] ?? '',
      municipioComercial: json["municipio_comercial"] ?? '',
      emailComercial: json["email_comercial"] ?? '',
      ciiu1: json["ciiu_1"] ?? '',
      ciiu2: json["ciiu_2"] ?? '',
      ciiu3: json["ciiu_3"] ?? '',
      ciiu4: json["ciiu_4"] ?? '',
      actividad: json["actividad"] ?? '',
      tamaOEmpresa: json["tama_o_empresa"] ?? '',
      matriculaPropietario: json["matricula_propietario"] ?? '',
      nitPropietario: json["nit_propietario"] ?? '',
      camaraDePropietario: json["camara_de_propietario"] ?? '',
      nombreDePropietario: json["nombre_de_propietario"] ?? '',
      direccionPropietario: json["direccion_propietario"] ?? '',
      municipioPropietario: json["municipio_propietario"] ?? '',
      emailPropietario: json["email_propietario"] ?? '',
      representanteLegalSuplente: json["representante_legal_suplente"] ?? '',
    );
  }
}
